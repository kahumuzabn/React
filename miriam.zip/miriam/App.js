import React from 'react';
import {Text, View} from 'react-native';
import Cafe from './Tutorials/FunctionAsConstant2';
import Stat from './Tutorials/UsingState';
import Scrow from './Tutorials/ScrollViewin';
import FlatlistBasic from './Tutorials/Listin';
import SectionListBasics from './Tutorials/SectionLis';
import Ben from './Tutorials/FetchDt';
import AddDt from './Tutorials/TextInputHandle';

const App = ( ) => { 
  return (
    <View>
<AddDt/>
</View>
  );
}
export default App;